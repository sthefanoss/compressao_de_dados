%--------------------------------------------------------------------------
function result=returnPartOfString(str,startindex,endindex)
result=str(startindex:endindex);
end
