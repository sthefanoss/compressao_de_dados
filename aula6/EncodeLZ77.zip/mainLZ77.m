% Separado em fun��es e com main Script

%Email: samira_ebrahimi@hotmail.com ,please contact me if you could improve
%this code, Thanks.
%function [timeC,timeDC,sourcestr,decoded]=mainLZ77(sourcestr)
%function [timeC,timeDC,sourcestr,decoded]=mainLZ77(sourcestr)
clear all; close all;
sourcestr = 'sir sid eastman easily teases sea sick seals';


searchWindowLen= 31;
lookAheadWindowLen= 31;
tic
      fprintf('LZ77-Compression is started.');
      
      sourcestr=[sourcestr '$'];
      coded=encodeLZ77(sourcestr,searchWindowLen,lookAheadWindowLen);
      
      fprintf('\n LZ77-Compression is finished.');
timeC=toc;
tic
    fprintf('\n LZ77-Decompression is started.');
    
    decoded=decodeLZ77(coded,searchWindowLen,lookAheadWindowLen);
    
    fprintf('\n LZ77-Decompression is finished.');
timeDC=toc;
ok=isequal(sourcestr,decoded)
%end
