function str=strcatNew(first,second)
str=[first second];
end